#Example 1
i = 1
while i < 6:
  print(i)
  i += 1
  
#Example 2
i = 1
while i < 6:
  print(i)
  i += 1
else:
  print("i is no longer less than 6")

